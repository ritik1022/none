export class FoodModel{
    id : number = 0;
    category : string = '';
    cuisinename : string = '';
    description : string = '';
    foodname : string = '';
    offers : string = '';
    price : number = 0;
    status : string = '';
  
}
