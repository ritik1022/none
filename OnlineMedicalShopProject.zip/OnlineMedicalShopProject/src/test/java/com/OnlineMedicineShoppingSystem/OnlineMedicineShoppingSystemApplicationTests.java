package com.OnlineMedicineShoppingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMedicineShoppingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
