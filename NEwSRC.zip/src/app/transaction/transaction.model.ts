export class transaction{
    id:number=0;
    address:string='';
    amount:number=0;
    mobilenumber:number=0;
    name:string='';

}