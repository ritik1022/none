
    export class MedicineModel{
        getMedicineById(id: any): MedicineModel {
          throw new Error('Method not implemented.');
        }
        medicineId : number = 0;
        
        medicineDescription : string = '';
        medicineName : string = '';
        medicinePrice : number = 0;
        instock : string = '';
    }
    
