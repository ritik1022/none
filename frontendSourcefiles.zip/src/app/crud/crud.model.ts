export class MedicineModel{
    medicineId : number = 0;
    
    medicineDescription : string = '';
    medicineName : string = '';
    
    medicinePrice : number = 0;
    instock : string = '';
  
}
